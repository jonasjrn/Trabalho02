package com.mycompany.calculadora;

import java.util.Scanner;

public class TestaCalculadora {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String operador;

        while (true) {
            System.out.print("Digite o operador (+, -, *, /) ou '.' para sair: ");
            operador = scanner.next();

            if (operador.equals(".")) {
                break; // Encerra o programa
            }

            System.out.print("Digite o primeiro número: ");
            double num1 = scanner.nextDouble();

            System.out.print("Digite o segundo número: ");
            double num2 = scanner.nextDouble();

            // Criar uma instância da Calculadora
            Calculadora calc = new Calculadora(num1, num2);

            // Verifica o operador e executa a operação correspondente
            switch (operador) {
                case "+":
                    System.out.printf("Resultado: %.2f%n", calc.some());
                    break;
                case "-":
                    System.out.printf("Resultado: %.2f%n", calc.subtraia());
                    break;
                case "*":
                    System.out.printf("Resultado: %.2f%n", calc.multiplique());
                    break;
                case "/":
                    System.out.printf("Resultado: %.2f%n", calc.divida());
                    break;
                default:
                    System.out.println("Operador inválido!");
                    break;
            }
        }

        scanner.close();
        System.out.println("Calculadora encerrada.");
    }
}